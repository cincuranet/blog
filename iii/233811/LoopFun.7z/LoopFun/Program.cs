﻿using System.Linq;
using BenchmarkDotNet.Attributes;
using BenchmarkDotNet.Running;

namespace LoopFun
{
	class Program
	{
		static void Main(string[] args)
		{
			BenchmarkRunner.Run<Fun>();
		}
	}

	[DisassemblyDiagnoser]
	public class Fun
	{
		int[] Data;

		[GlobalSetup]
		public void GlobalSetup()
		{
			Data = Enumerable.Range(0, 5000).ToArray();
		}

		[Benchmark(Baseline = true)]
		public void SumA()
		{
			for (var i = 0; i < Data.Length; i++)
			{
				Data[i] = i;
			}
		}

		[Benchmark]
		public void SumB()
		{
			for (int i = Data.Length - 1; i >= 0; i--)
			{
				Data[i] = i;
			}
		}

		[Benchmark]
		public void SumC()
		{
			var length = Data.Length;
			for (var i = 0; i < length; i++)
			{
				Data[i] = i;
			}
		}
	}
}
