﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Entity;

namespace VeryOldAwesomeApplication
{
	public partial class Form1 : Form
	{
		MyContext MyContext { get; set; }

		public Form1()
		{
			InitializeComponent();
			MyContext = new MyContext();
			tbOwnerId.DataBindings.Add("Text", ownersBindingSource, "Id");
			tbOwnerFirstName.DataBindings.Add("Text", ownersBindingSource, "FirstName");
			tbOwnerLastName.DataBindings.Add("Text", ownersBindingSource, "LastName");
		}

		private void Form1_Load(object sender, EventArgs e)
		{
			ownersBindingSource.DataSource = MyContext.Owners.Include(x => x.Dogs).ToList();
		}

		private void Form1_FormClosed(object sender, FormClosedEventArgs e)
		{
			MyContext.Dispose();
		}

		private void BindingNavigator1_RefreshItems(object sender, EventArgs e)
		{
			dogsBindingSource.DataSource = (ownersBindingSource.Current as Owner)?.Dogs;
		}
	}
}
