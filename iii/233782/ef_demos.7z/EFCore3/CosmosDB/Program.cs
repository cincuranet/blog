﻿using EFCore3;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using System;

namespace CosmosDB
{
	class Program
	{
		public static readonly ILoggerFactory MyLoggerFactory = LoggerFactory.Create(builder => builder.SetMinimumLevel(LogLevel.Trace).AddConsole());

		static void Main(string[] args)
		{
			using (var db = new CosmosContext())
			{
				db.Database.EnsureCreated();
				db.Owners.Add(new Owner()
				{
					Id = (int)DateTime.UtcNow.Ticks,
					FirstName = "test",
					LastName = "test",
					Dogs = new[]
					{
						new Dog() { Id = (int)DateTime.UtcNow.Ticks, Name = "aaa", DateOfBirth = DateTime.Now },
					},
				});
				db.SaveChanges();
				foreach (var item in db.Owners)
					Console.WriteLine(item.Id);
			}
		}
	}

	class CosmosContext : DbContext
	{
		public DbSet<Owner> Owners => Set<Owner>();

		protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
		{
			base.OnConfiguring(optionsBuilder);

			optionsBuilder
				.EnableSensitiveDataLogging()
				.UseLoggerFactory(Program.MyLoggerFactory)
				.UseCosmos("https://efcore-demo.documents.azure.com:443/", "KhsrUoBI8fvXIAGR1cTIZkFtgFLoXvHN5AjUvWGvJ60pHR6JCYktw4nbwVQa9whcqZE9KNrnOHzEA7wPqmQuAA==", "ntk");
		}

		protected override void OnModelCreating(ModelBuilder modelBuilder)
		{
			base.OnModelCreating(modelBuilder);

			modelBuilder.Entity<Owner>().OwnsMany(x => x.Dogs);
			modelBuilder.Entity<Owner>().ToContainer("data");
		}
	}
}
