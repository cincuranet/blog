﻿using EFCore3;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.Extensions.Logging;
using System;
using System.Linq;

#pragma warning disable CS0618

namespace EFCorePrevious
{
	class Program
	{
		/*
		 * EF Core 2
		 */ 
		static void Main(string[] args)
		{
			using (var db = new MyContext())
			{
				db.GetService<ILoggerFactory>().AddConsole();
				//db.Database.EnsureDeleted();
				//db.Database.EnsureCreated();

				db.Owners.Where(x => x.Dogs.Any(d => d.DateOfBirth.Add(TimeSpan.FromDays(-1000)) < DateTime.Now)).ToList();

				//var id = 10;
				//db.Owners.FromSql($"select * from Owners where Id = {id}");

				db.Owners.Add(new Owner() { FirstName = "test", LastName = "test" });
				db.SaveChanges();
			}
		}
	}
}
