﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using System;

#nullable enable

namespace Nullable
{
	class Program
	{
		static void Main(string[] args)
		{
var coreAssemblyInfo = System.Diagnostics.FileVersionInfo.GetVersionInfo(typeof(object).Assembly.Location);
Console.WriteLine($"Hello World from Core {coreAssemblyInfo.ProductVersion}");
Console.WriteLine($"The location is {typeof(object).Assembly.Location}");
			using (var db = new MyContext())
			{
				db.Database.EnsureDeleted();
				db.Database.EnsureCreated();
			}
		}
	}
	public class MyContext : DbContext
	{
		public DbSet<Dog> Dogs => Set<Dog>();

		protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
		{
			base.OnConfiguring(optionsBuilder);

			optionsBuilder
				.EnableDetailedErrors()
				.UseSqlServer(@"server=(localdb)\mssqllocaldb;database=DogOwners;Integrated Security=true;ConnectRetryCount=0")
				;
		}

		protected override void OnModelCreating(ModelBuilder modelBuilder)
		{
			base.OnModelCreating(modelBuilder);

			foreach (var entity in modelBuilder.Model.GetEntityTypes())
			{
				foreach (var property in entity.GetProperties())
				{
					if (property.ClrType == typeof(string))
					{
						property.SetMaxLength(100);
					}
				}
			}
		}
	}


	public class Dog
	{
		public int Id { get; set; }
		public string? Name { get; set; }
		public string Name2 { get; set; }
		public DateTime DateOfBirth { get; set; }
	}
}
