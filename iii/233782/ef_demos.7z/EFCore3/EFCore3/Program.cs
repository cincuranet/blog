﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;

namespace EFCore3
{
	/*
	 * EF Core 3
	 */
	class Program
	{
		public static readonly ILoggerFactory MyLoggerFactory = LoggerFactory.Create(builder => builder.SetMinimumLevel(LogLevel.Trace).AddConsole());

		static void Main(string[] args)
		{
			using (var db = new MyContext())
			{
				db.Database.EnsureDeleted();
				db.Database.EnsureCreated();

				//db.Owners.Where(x => x.Dogs.Any(d => d.DateOfBirth.Add(TimeSpan.FromDays(-1000)) < DateTime.Now)).ToList();

				//db.Add(new PropertyBagEntity());
				//db.SaveChanges();

				//var id = 10;
				////db.Owners.FromSqlRaw()
				//db.Owners.FromSqlInterpolated($"select * from Owners where Id = {id}");

				//db.Owners.Add(new Owner() { FirstName = "test", LastName = "test" });
				//db.SaveChanges();
			}
		}
	}	
}
