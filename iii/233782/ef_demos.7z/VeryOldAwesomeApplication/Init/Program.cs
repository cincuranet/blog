﻿using System;
using VeryOldAwesomeApplication;

namespace Init
{
	class Program
	{
		static void Main(string[] args)
		{
			using (var db = new MyContext())
			{
				db.Database.Delete();
				db.Database.Create();
				db.Owners.Add(new Owner()
				{
					FirstName = "First",
					LastName = "Owner",
					Dogs = new[]
					{
						new Dog() { Name = "Wolf", DateOfBirth = DateTime.Now },
						new Dog() { Name = "Azor", DateOfBirth = DateTime.Now },
					}
				});
				db.Owners.Add(new Owner()
				{
					FirstName = "Second",
					LastName = "Owner2",
					Dogs = new[]
					{
						new Dog() { Name = "Hugo", DateOfBirth = new DateTime(1990, 1, 4) },
						new Dog() { Name = "Jack", DateOfBirth = new DateTime(1991, 1, 4) },
						new Dog() { Name = "Jen", DateOfBirth = new DateTime(1992, 1, 4) },
					}
				});
				db.SaveChanges();
			}
		}
	}
}
