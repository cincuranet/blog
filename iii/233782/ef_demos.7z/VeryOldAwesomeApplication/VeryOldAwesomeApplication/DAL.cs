﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.SqlClient;

namespace VeryOldAwesomeApplication
{
	public class MyContext : DbContext
	{
		public MyContext()
			: base(new SqlConnection(@"server=(localdb)\mssqllocaldb;database=DogOwners;Integrated Security=true"), true)
		{ }

		public DbSet<Owner> Owners { get; set; }
		public DbSet<Dog> Dogs { get; set; }

		protected override void OnModelCreating(DbModelBuilder modelBuilder)
		{
			base.OnModelCreating(modelBuilder);

			modelBuilder.Properties<string>()
				.Configure(c => c.HasMaxLength(100));
		}
	}


	public class Owner
	{
		public int Id { get; set; }
		public string FirstName { get; set; }
		public string LastName { get; set; }
		public ICollection<Dog> Dogs { get; set; }
	}

	public class Dog
	{
		public int Id { get; set; }
		public string Name { get; set; }
		public DateTime DateOfBirth { get; set; }
		public int OwnerId { get; set; }
		public Owner Owner { get; set; }
	}
}
