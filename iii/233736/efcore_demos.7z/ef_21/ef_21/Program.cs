﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.ChangeTracking;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.Extensions.Logging;

namespace ef_21
{
	static class Config
	{
		public const string ConnectionString = @"Server=(localdb)\mssqllocaldb;Integrated Security=true;Initial Catalog=ef21;ConnectRetryCount=0";
	}

	class Program
	{
		static void Main(string[] args)
		{
			//using (var db = new LazyLoadingContext())
			//{
			//	db.Database.EnsureDeleted();
			//	db.Database.EnsureCreated();
			//	db.Database.ExecuteSqlCommand("insert into Region (Name) values ('ABC')");
			//	db.Database.ExecuteSqlCommand("insert into Region (Name) values ('FooBar')");
			//	db.Database.ExecuteSqlCommand("insert into Person (Name, RegionId) values ('Test1', 1)");
			//	db.Database.ExecuteSqlCommand("insert into Person (Name, RegionId) values ('Test2', 2)");
			//	db.Database.ExecuteSqlCommand("insert into Person (Name, RegionId) values ('Foo', 2)");
			//	db.GetService<ILoggerFactory>().AddConsole();

			//	foreach (var p in db.Set<Person>())
			//	{
			//		Console.WriteLine(p.GetType().Name);
			//		Console.WriteLine(p.Region.Name);
			//	}
			//}

			//using (var db = new GroupByContext())
			//{
			//	db.Database.EnsureDeleted();
			//	db.Database.EnsureCreated();
			//	db.GetService<ILoggerFactory>().AddConsole();
			//	db.Set<Person>()
			//		.GroupBy(x => x.RegionId)
			//		.Select(g => new { g.Key, Count = g.Count() })
			//		.Load();
			//}

			//using (var db = new ValueConvertersContext())
			//{

			//}

			//using (var db = new SeedContext())
			//{
			//	db.Database.EnsureDeleted();
			//	db.GetService<ILoggerFactory>().AddConsole();
			//	db.Database.EnsureCreated();
			//}

			//using (var db = new QueryContext())
			//{
			//	db.Database.EnsureDeleted();
			//	db.Database.EnsureCreated();
			//	db.GetService<ILoggerFactory>().AddConsole();
			//	var data = db.Query<RegionCount>()
			//		.FromSql(@"
			//		select r.Name, count(p.Id) as Count
			//		from Region r left join Person p on (r.Id = p.RegionId)
			//		group by r.Name").ToList();
			//}

			//void Added(object sender, EntityTrackedEventArgs e) => Console.WriteLine($"Added: {e.FromQuery}|{e.Entry.Entity}");
			//void StateChanged(object sender, EntityStateChangedEventArgs e) => Console.WriteLine($"StateChanged: {e.OldState}|{e.NewState}|{e.Entry.Entity}");
			//using (var db = new ChangeTrackerEventsContext(Added, StateChanged))
			//{
			//	db.Database.EnsureDeleted();
			//	db.Database.EnsureCreated();
			//	db.Database.ExecuteSqlCommand("insert into Region (Name) values ('ABC')");
			//	db.Add(new Region());
			//	var regions = db.Set<Region>().ToList();
			//	regions.First().Name = DateTime.UtcNow.ToString();
			//	db.ChangeTracker.DetectChanges();
			//}

			//using (var db = new QueriesN1())
			//{
			//	db.Database.EnsureDeleted();
			//	db.Database.EnsureCreated();
			//	db.Database.ExecuteSqlCommand("insert into Region (Name) values ('ABC')");
			//	db.Database.ExecuteSqlCommand("insert into Region (Name) values ('FooBar')");
			//	db.Database.ExecuteSqlCommand("insert into Person (Name, RegionId) values ('Test1', 1)");
			//	db.Database.ExecuteSqlCommand("insert into Person (Name, RegionId) values ('Test2', 2)");
			//	db.Database.ExecuteSqlCommand("insert into Person (Name, RegionId) values ('Foo', 2)");
			//	db.GetService<ILoggerFactory>().AddConsole();
			//	db.Set<Region>()
			//		.Select(r => r.People
			//			.Where(p => p.Name != string.Empty)
			//			.Select(p => p.Name)
			//			.ToList())
			//		.Load();
			//}
		}
	}

	public class Person
	{
		public int Id { get; set; }
		public string Name { get; set; }
		public virtual int RegionId { get; set; }
		public virtual Region Region { get; set; }
	}
	public class Region
	{
		public int Id { get; set; }
		public string Name { get; set; }
		public virtual ICollection<Person> People { get; set; }
	}

	public class PersonLazyLoader
	{
		readonly ILazyLoader _lazyLoader;

		public PersonLazyLoader()
		{ }

		public PersonLazyLoader(ILazyLoader lazyLoader)
		{
			_lazyLoader = lazyLoader;
		}

		//public PersonLazyLoader(Action<object, string> lazyLoader) { }
		/*
public static class PocoLoadingExtensions
{
    public static TRelated Load<TRelated>(
        this Action<object, string> loader,
        object entity,
        ref TRelated navigationField,
        [CallerMemberName] string navigationName = null)
        where TRelated : class
    {
        loader?.Invoke(entity, navigationName);
        return navigationField;
    }
}
		 */

		Region _region;
		public Region Region
		{
			get => _lazyLoader.Load(this, ref _region);
			set => _region = value;
		}
	}

	public class Post
	{
		public Post(int id, string title, DateTime postedOn)
		{
			Id = id;
			Title = title;
			PostedOn = postedOn;
		}

		public int Id { get; private set; }
		public string Title { get; }
		public string Content { get; set; }
		public DateTime PostedOn { get; set; }
		/*
modelBuilder.Entity<Post>(
	b =>
	{
		b.HasKey("Id");
		b.Property(e => e.Title);
	});
		 */
	}

	public class RegionCount
	{
		public string Name { get; set; }
		public int Count { get; set; }
	}

	class ValueConvertersContext : MyContext
	{
		// Value converters
		// https://www.tabsoverspaces.com/233708-using-value-converter-for-custom-encryption-of-field-on-entity-framework-core-2-1/
	}

	class MyContext : DbContext
	{
		protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
		{
			base.OnConfiguring(optionsBuilder);

			optionsBuilder
				.UseSqlServer(Config.ConnectionString);
		}

		protected override void OnModelCreating(ModelBuilder modelBuilder)
		{
			base.OnModelCreating(modelBuilder);

			modelBuilder.Entity<Person>();
			modelBuilder.Entity<Region>();
		}
	}

	class LazyLoadingContext : MyContext
	{
		protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
		{
			base.OnConfiguring(optionsBuilder);

			optionsBuilder
				// Microsoft.EntityFrameworkCore.Proxies 
				.UseLazyLoadingProxies();
		}
	}

	class GroupByContext : MyContext
	{ }

	class SeedContext : MyContext
	{
		protected override void OnModelCreating(ModelBuilder modelBuilder)
		{
			base.OnModelCreating(modelBuilder);

			modelBuilder.Entity<Region>().HasData(new Region { Id = 35, Name = "Test" });
			modelBuilder.Entity<Person>().HasData(new Person { Id = 1234, Name = "Test", RegionId = 35 });
		}
	}

	class QueryContext : MyContext
	{
		protected override void OnModelCreating(ModelBuilder modelBuilder)
		{
			base.OnModelCreating(modelBuilder);

			modelBuilder.Query<RegionCount>();
		}
	}

	class ChangeTrackerEventsContext : MyContext
	{
		public ChangeTrackerEventsContext(EventHandler<EntityTrackedEventArgs> tracked, EventHandler<EntityStateChangedEventArgs> stateChanged)
		{
			ChangeTracker.Tracked += tracked;
			ChangeTracker.StateChanged += stateChanged;
		}
	}

	class QueriesN1 : MyContext
	{ }
}
