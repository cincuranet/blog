﻿//#define TABLE_SPLITTING

using System;
using System.Diagnostics;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Diagnostics;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

namespace ef_20
{
	static class Config
	{
		public const string ConnectionString = @"Server=(localdb)\mssqllocaldb;Integrated Security=true;Initial Catalog=ef20;ConnectRetryCount=0";
	}

	class Program
	{
		static void Main(string[] args)
		{
			//ClientSideEvaluation();
			//Like();
			//OwnedEntity();
			//TableSplitting();
			//GlobalQueryFilters();
			//StringInterpolationSql();
			//CompileQuery();
			//SelfContainedConfiguration();
			//DatabaseFunctions();
			//ContextPooling().GetAwaiter().GetResult();
		}

		static void ClientSideEvaluation()
		{
			using (var db = new ClienSideEvaluationContext())
			{
				db.SetUpDemo();
				db.People.GroupBy(x => x.CityId).Select(x => new
				{
					CityId = x.Key,
					Count = x.Count(),
				}).Load();
			}
		}

		static void Like()
		{
			using (var db = new LikeContext())
			{
				db.SetUpDemo();
				db.People.Where(x => EF.Functions.Like(x.LastName, "A%B%")).Load();
				db.People.Where(x => x.LastName.Contains("AB")).Load();
			}
		}

		static void OwnedEntity()
		{
			using (var db = new OwnedEntityContext())
			{
				db.SetUpDemo();
			}
		}

		static void TableSplitting()
		{
			using (var db = new TableSplittingContext())
			{
				db.SetUpDemo();
				db.People.Load();
				db.PeopleExtras.Load();
			}
		}

		static void GlobalQueryFilters()
		{
			using (var db = new GlobalQueryFiltersContext(6))
			{
				db.SetUpDemo();
				db.People.Load();
				db.People.IgnoreQueryFilters().Load();
			}
		}

		static void StringInterpolationSql()
		{
			using (var db = new StringInterpolationSqlContext())
			{
				db.SetUpDemo();
				var departmentId = 6;
				db.People.FromSql($"select * from People where DepartmentId = {departmentId}").Load();
			}
		}

		static void CompileQuery()
		{
			// automatic caching based on expression hash
			// bypasses the hash computation and lookup
			var query = EF.CompileQuery<CompileQueryContext, int, int>((context, departmentId) => context.People.Where(x => x.DepartmentId == departmentId).Count());
			using (var db = new CompileQueryContext())
			{
				db.SetUpDemo();
				var count = query(db, 66);
			}
		}

		static void SelfContainedConfiguration()
		{
			using (var db = new SelfContainedConfigurationContext())
			{
				db.SetUpDemo();
			}
		}

		static void DatabaseFunctions()
		{
			using (var db = new DatabaseFunctionsContext())
			{
				db.SetUpDemo();
				db.Database.ExecuteSqlCommand("create function dbo.FooBar(@s nvarchar(200)) returns int as begin return len(@s) end");
				db.People.Select(x => new
				{
					Id = x.Id,
					FooBar = DatabaseFunctionsContext.FooBar(x.FirstName),
				}).Load();
			}
		}

		static Task ContextPooling()
		{
			const int Threads = 32;
			const int Seconds = 10;

			long RequestsProcessed = 0;

			async Task SimulateRequestsAsync(IServiceProvider serviceProvider, Stopwatch stopwatch)
			{
				while (stopwatch.IsRunning)
				{
					using (var serviceScope = serviceProvider.CreateScope())
					{
						await new ContextPoolingContextController(serviceScope.ServiceProvider.GetService<ContextPoolingContext>()).ActionAsync();
					}

					Interlocked.Increment(ref RequestsProcessed);
				}
			}

			async void MonitorResults(TimeSpan duration, Stopwatch stopwatch)
			{
				var lastInstanceCount = 0L;
				var lastRequestCount = 0L;
				var lastElapsed = TimeSpan.Zero;

				stopwatch.Start();

				while (stopwatch.Elapsed < duration)
				{
					await Task.Delay(TimeSpan.FromSeconds(1));

					var instanceCount = ContextPoolingContext.Instances;
					var requestCount = RequestsProcessed;
					var elapsed = stopwatch.Elapsed;
					var currentElapsed = elapsed - lastElapsed;
					var currentRequests = requestCount - lastRequestCount;

					Console.WriteLine(
						$"[{DateTime.Now:HH:mm:ss.fff}] "
						+ $"Context creations/second: {instanceCount - lastInstanceCount} | "
						+ $"Requests/second: {Math.Round(currentRequests / currentElapsed.TotalSeconds)}");

					lastInstanceCount = instanceCount;
					lastRequestCount = requestCount;
					lastElapsed = elapsed;
				}

				Console.WriteLine();
				Console.WriteLine($"Total context creations: {ContextPoolingContext.Instances}");
				Console.WriteLine($"Requests per second:     {Math.Round(RequestsProcessed / stopwatch.Elapsed.TotalSeconds)}");

				stopwatch.Stop();
			}

			async Task Run()
			{
				var serviceCollection = new ServiceCollection();
				new ContextPoolingContextStartup().ConfigureServices(serviceCollection);
				var serviceProvider = serviceCollection.BuildServiceProvider();

				var stopwatch = new Stopwatch();

				MonitorResults(TimeSpan.FromSeconds(Seconds), stopwatch);

				await Task.WhenAll(Enumerable.Range(0, Threads).Select(_ => SimulateRequestsAsync(serviceProvider, stopwatch)));
			}

			return Run();
		}
	}

	class Person
	{
		public int Id { get; set; }
		public string FirstName { get; set; }
		public string LastName { get; set; }
		public City City { get; set; }
		public int CityId { get; set; }
		public Department Department { get; set; }
		public int DepartmentId { get; set; }

#if TABLE_SPLITTING
		public PersonExtra Extra { get; set; }
#endif
	}

	class PersonExtra
	{
		public int Id { get; set; }
		public decimal Whatever { get; set; }
		public Person Person { get; set; }
	}

	class Department
	{
		public int Id { get; set; }
		public string Name { get; set; }
	}

	class City
	{
		public int Id { get; set; }
		public string Name { get; set; }
		public int CountryId { get; set; }
		public Country Country { get; set; }
	}

	class Country
	{
		public int Id { get; set; }
		public string Name { get; set; }
	}

	abstract class DemoContext : DbContext
	{
		public DbSet<Person> People { get; set; }

		protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
		{
			base.OnConfiguring(optionsBuilder);
			optionsBuilder.UseSqlServer(Config.ConnectionString);
		}
	}

	class ClienSideEvaluationContext : DemoContext
	{
		protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
		{
			base.OnConfiguring(optionsBuilder);
			optionsBuilder.ConfigureWarnings(w => w.Throw(RelationalEventId.QueryClientEvaluationWarning));
		}
	}

	class LikeContext : DemoContext
	{ }

	class OwnedEntityContext : DemoContext
	{
		protected override void OnModelCreating(ModelBuilder modelBuilder)
		{
			base.OnModelCreating(modelBuilder);
			modelBuilder.Entity<Person>()
				.OwnsOne(x => x.City);
		}
	}

	class TableSplittingContext : DemoContext
	{
		public DbSet<PersonExtra> PeopleExtras { get; set; }

		protected override void OnModelCreating(ModelBuilder modelBuilder)
		{
			base.OnModelCreating(modelBuilder);
#if TABLE_SPLITTING
			var personExtraConf = modelBuilder.Entity<PersonExtra>();
			personExtraConf.HasOne(x => x.Person).WithOne(x => x.Extra).HasPrincipalKey<Person>(x => x.Id);
			personExtraConf.ToTable("People");
#endif
		}
	}

	class GlobalQueryFiltersContext : DemoContext
	{
		readonly int _departmentId;

		public GlobalQueryFiltersContext(int departmentId)
		{
			_departmentId = departmentId;
		}

		protected override void OnModelCreating(ModelBuilder modelBuilder)
		{
			base.OnModelCreating(modelBuilder);
			modelBuilder.Entity<Person>()
				.HasQueryFilter(x => x.DepartmentId != _departmentId);
		}
	}

	class StringInterpolationSqlContext : DemoContext
	{ }

	class CompileQueryContext : DemoContext
	{ }

	class SelfContainedConfigurationContext : DemoContext
	{
		protected override void OnModelCreating(ModelBuilder modelBuilder)
		{
			base.OnModelCreating(modelBuilder);
			modelBuilder.ApplyConfiguration(new CityConfiguration());
		}
	}
	class CityConfiguration : IEntityTypeConfiguration<City>
	{
		public void Configure(EntityTypeBuilder<City> builder)
		{
			builder.ToTable("MESTAAAAAAAAAAAAAAAAAAA");
		}
	}

	class DatabaseFunctionsContext : DemoContext
	{
		[DbFunction("FooBar", "dbo")]
		public static int FooBar(string s) => throw new InvalidOperationException();
	}

	class ContextPoolingContext : DemoContext
	{
		public static long Instances;

		public ContextPoolingContext(DbContextOptions options)
		{
			Interlocked.Increment(ref Instances);
		}
	}
	class ContextPoolingContextController
	{
		readonly ContextPoolingContext _context;

		public ContextPoolingContextController(ContextPoolingContext context) => _context = context;

		public async Task ActionAsync() => await _context.People.LoadAsync();
	}
	class ContextPoolingContextStartup
	{
		public void ConfigureServices(IServiceCollection services)
		{
			//services.AddDbContext<ContextPoolingContext>();
			services.AddDbContextPool<ContextPoolingContext>(_ => { });
		}
	}

	static class Ext
	{
		public static void SetUpDemo(this DbContext context)
		{
			context.Database.EnsureDeleted();
			context.Database.EnsureCreated();
			context.GetService<ILoggerFactory>().AddConsole();
		}
	}
}
