﻿using System.Net;
using System.Net.Quic;
using System.Net.Security;
using System.Text;

namespace Client
{
    internal class Program
    {
        static async Task Main(string[] args)
        {
            Console.Title = "Client";
            Console.WriteLine("Ready?");
            Console.ReadLine();
            var options = new QuicClientConnectionOptions()
            {
                RemoteEndPoint = new IPEndPoint(IPAddress.IPv6Loopback, 3663),
                ClientAuthenticationOptions = new SslClientAuthenticationOptions()
                {
                    ApplicationProtocols = new() { new SslApplicationProtocol("jiri") },
                    RemoteCertificateValidationCallback = (_, _, _, _) => true,
                },
                DefaultStreamErrorCode = 0x3FFFFFFFFFFFFFFF,
                DefaultCloseErrorCode = 0x100,
            };
            await using (var client = await QuicConnection.ConnectAsync(options))
            {
                await using (var stream = await client.OpenOutboundStreamAsync(QuicStreamType.Bidirectional))
                {
                    for (var i = 0; i < 5; i++)
                    {
                        var message = $"Hello {i}";
                        Console.WriteLine($"Sending: [{message}].");
                        var data = Encoding.UTF8.GetBytes(message);
                        await stream.WriteAsync(new[] { (byte)data.Length });
                        await stream.WriteAsync(data);
                        await stream.FlushAsync();
                        await Task.Delay(Random.Shared.Next(0, 5000));
                    }
                }
            }
        }
    }
}