﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ConsoleApp1
{
	class Program
	{
		static void Main(string[] args)
		{
			//for (var i = 0; i < 15000; i++)
			//{
			//	var t = new Thread(_ =>
			//	{
			//		Thread.Sleep(-1);
			//	});
			//	t.Start();
			//	Console.WriteLine(i);
			//}
			Console.ReadLine();
		}
	}
}
