﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
	public partial class Form1 : Form
	{
		public Form1()
		{
			InitializeComponent();
		}

		private void button1_Click(object sender, EventArgs e)
		{
			Do().Wait();
			button1.Text = DateTime.Now.ToString();
		}

		//static async Task Do()
		//{
		//	await Task.Delay(2000);
		//}

		static async Task ReadStreamAsync(Stream source, Stream destination)
		{
			var buffer = new byte[32 * 1024];
			while (true)
			{
				try
				{
					var read = await source.ReadAsync(buffer, 0, buffer.Length).ConfigureAwait(false);
					if (read == 0)
					{
						break;
					}
					await destination.WriteAsync(buffer, 0, read).ConfigureAwait(false);
				}
				catch (IOException ex)
				{

				}
			}
		}
	}
}
