﻿using System.Text.Json;
using System.Text.Json.Serialization;

var json = JsonSerializer.Serialize(new Person(1, "Jiri", "Cincura"), MyJsonContext.Default.Person);
Console.WriteLine(json);
var person = JsonSerializer.Deserialize(json, MyJsonContext.Default.Person);
Console.WriteLine(person);

public class Person
{
	public int Id { get; set; }
	public string FirstName { get; set; }
	public string LastName { get; set; }

	public Person(int id, string firstName, string lastName)
	{
		Id = id;
		FirstName = firstName;
		LastName = lastName;
	}
}

[JsonSourceGenerationOptions(
	GenerationMode = JsonSourceGenerationMode.Metadata,
	PropertyNamingPolicy = JsonKnownNamingPolicy.CamelCase,
	WriteIndented = true)]
[JsonSerializable(typeof(Person))]
internal partial class MyJsonContext : JsonSerializerContext
{ }