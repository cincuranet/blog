﻿using System.Text.Json;
using System.Text.Json.Serialization;
using BenchmarkDotNet.Attributes;
using BenchmarkDotNet.Running;

BenchmarkRunner.Run<FooBar>();

[MemoryDiagnoser]
public class FooBar
{
	readonly Person _person = new Person(1, "Jiri", "Cincura");

	[Benchmark(Baseline = true)]
	public string Normal()
	{
		return JsonSerializer.Serialize(_person);
	}

	[Benchmark]
	public string Generator()
	{
		return JsonSerializer.Serialize(_person, MyJsonContext.Default.Person);
	}
}

public class Person
{
	public int Id { get; set; }
	public Name Name { get; set; }

	public Person(int id, string firstName, string lastName)
	{
		Id = id;
		Name = new Name(firstName, lastName);
	}
}

public record Name(string FirstName, string LastName);

[JsonSerializable(typeof(Person))]
internal partial class MyJsonContext : JsonSerializerContext
{ }