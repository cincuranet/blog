﻿using System;
using AutoNotify;

namespace SourceGenerators
{
	class Program
	{
		static void Main(string[] args)
		{
			//HelloConferenceGenerated.HelloConference.SayHello();
			//new CSV.Participants.Item();
			//new CSV.FooBar.Item();
			var n = new Notify();
			n.PropertyChanged += N_PropertyChanged;
			n.Name = "Test";
		}

		private static void N_PropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
		{
			Console.WriteLine($"Prop: {e.PropertyName}");
		}
	}

	partial class Notify
	{
		[AutoNotify]
		string _name;
	}
}
