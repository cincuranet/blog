﻿using Microsoft.EntityFrameworkCore;

namespace EFCore5.QueryUpdate
{
	public class QueryUpdateContext : DemoDbContext
	{
		protected override void OnModelCreating(ModelBuilder modelBuilder)
		{
			base.OnModelCreating(modelBuilder);
			modelBuilder.Entity<QueryUpdateEntity>()
				.ToTable("RealTable")
				// ToView
				.ToSqlQuery("select Id, Foo, Bar, Baz from SomeTable union all select Id, Foo, Bar, null from AnotherTable");
		}
	}

	class QueryUpdateEntity
	{
		public int Id { get; set; }
		public string Foo { get; set; }
	}
}
