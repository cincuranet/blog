﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Diagnostics;

namespace EFCore5
{
	public abstract class DemoDbContext : DbContext
	{
		protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
		{
			base.OnConfiguring(optionsBuilder);
			optionsBuilder.LogTo(x => Program.WriteLine(x, ConsoleColor.Cyan), (eventId, level) => eventId == RelationalEventId.CommandExecuting);
			optionsBuilder.UseSqlServer(Settings.SqlServerConnectionString);
		}
	}
}
