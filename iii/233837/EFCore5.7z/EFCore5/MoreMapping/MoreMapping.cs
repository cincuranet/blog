﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace EFCore5.MoreMapping
{
	public class MoreMappingContext : ElementaryDbContext
	{
		public IQueryable<TVFResult> CallTVF(int something)
			=> FromExpression(() => CallTVF(something));

		protected override void OnModelCreating(ModelBuilder modelBuilder)
		{
			base.OnModelCreating(modelBuilder);

			var conf = modelBuilder.Entity<MoreMappingEntity>();
			conf
				.Property(x => x.MoreId)
				.HasComputedColumnSql("Id * 2", stored: true);
			conf
				.Property(x => x.MoreNotSoMuchId)
				.HasComputedColumnSql("Id * 2", stored: false);
			conf
				.Property(x => x.PrecisionScale)
				.HasPrecision(16, 4);

			//modelBuilder.Entity<Dog>().Navigation(x => x.Owners).HasField("_foobar");

			modelBuilder.UseCollation("Czech_CI_AS");
			conf
				.Property(x => x.Collation)
				.UseCollation("Czech_CI_AS");

			modelBuilder.Entity<TVFResult>().HasNoKey();
			modelBuilder.HasDbFunction(() => CallTVF(default));
		}
	}

	public class MoreMappingEntity
	{
		public int Id { get; set; }
		public int MoreId { get; set; }
		public int MoreNotSoMuchId { get; set; }
		public decimal PrecisionScale { get; set; }
		public string Collation { get; set; }
	}

	public class TVFResult
	{
		public string S { get; set; }
	}
}
