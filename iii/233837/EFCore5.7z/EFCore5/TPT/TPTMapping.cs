﻿using Microsoft.EntityFrameworkCore;

namespace EFCore5.TPT
{
	public class TPTContext : DemoDbContext
	{
		public DbSet<Vehicle> Vehicles { get; set; }
		public DbSet<Car> Cars { get; set; }
		public DbSet<Plane> Planes { get; set; }

		protected override void OnModelCreating(ModelBuilder modelBuilder)
		{
			base.OnModelCreating(modelBuilder);
			modelBuilder.Entity<Vehicle>().ToTable("Vehicles");
			modelBuilder.Entity<Car>().ToTable("Cars");
			modelBuilder.Entity<Plane>().ToTable("Planes");
		}
	}

	public class Vehicle
	{
		public int Id { get; set; }
		public decimal Price { get; set; }
		public string Name { get; set; }
	}
	public class Car : Vehicle
	{
		public double LitersPerKilometer { get; set; }
	}
	public class Plane : Vehicle
	{
		public int MaximumTakeoffWeight { get; set; }
		public int MaximumLandingWeight { get; set; }
	}
}
