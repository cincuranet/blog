﻿namespace EFCore5
{
	static class Settings
	{
		public const string SqlServerConnectionString = "Data Source=localhost;Initial Catalog=EFCore5;Integrated Security=True;ConnectRetryCount=0";
	}
}
