﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace EFCore5.RequiredOneOnOneDependents
{
	public class RequiredOneOnOneDependentsContext : DemoDbContext
	{
		protected override void OnModelCreating(ModelBuilder modelBuilder)
		{
			base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<Person>(x =>
            {
                x.OwnsOne(y => y.HomeAddress,
                    y =>
                    {
                        y.Property(z => z.Street).IsRequired();
                        y.Property(z => z.City).IsRequired();
                        y.Property(z => z.Postcode).IsRequired();
                    });
                x.Navigation(y => y.HomeAddress).IsRequired();

                x.OwnsOne(y => y.WorkAddress);
            });
        }
	}

    public class Person
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public Address HomeAddress { get; set; }
        public Address WorkAddress { get; set; }
    }

    public class Address
    {
        public string Street { get; set; }
        public string City { get; set; }
        public string Postcode { get; set; }
    }
}
