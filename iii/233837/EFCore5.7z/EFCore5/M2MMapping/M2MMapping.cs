﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace EFCore5.M2MMapping
{
	public class M2MContext : DemoDbContext
	{
		public DbSet<Dog> Dogs { get; set; }
		public DbSet<Owner> Owners { get; set; }

		protected override void OnModelCreating(ModelBuilder modelBuilder)
		{
			base.OnModelCreating(modelBuilder);
			modelBuilder
				.Entity<Dog>()
				.HasMany(x => x.Owners)
				.WithMany(x => x.Dogs)
				.UsingEntity<Dog2Owner>(
					b => b.HasOne(x => x.Owner).WithMany(),
					b => b.HasOne(x => x.Dog).WithMany())
			   .Property(x => x.Created);
		}
	}

	public class Dog
	{
		public int Id { get; set; }
		public string Name { get; set; }
		public DateTimeOffset Created { get; set; }
		public ICollection<Owner> Owners { get; set; }
	}

	public class Owner
	{
		public int Id { get; set; }
		public string FirstName { get; set; }
		public string LastName { get; set; }
		public DateTimeOffset Created { get; set; }
		public ICollection<Dog> Dogs { get; set; }
	}

	public class Dog2Owner
	{
		public Dog Dog { get; set; }
		public Owner Owner { get; set; }
		public DateTimeOffset Created { get; set; }
	}
}
