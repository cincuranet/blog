﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace EFCore5.PropertyBags
{
	public class PropertyBagsContext : DemoDbContext
	{
		public DbSet<Dictionary<string, object>> Dogs => Set<Dictionary<string, object>>("Dog");
		public DbSet<PropertyBagDog> PropertyBagDogs => Set<PropertyBagDog>();

		protected override void OnModelCreating(ModelBuilder modelBuilder)
		{
			base.OnModelCreating(modelBuilder);

            modelBuilder.SharedTypeEntity<Dictionary<string, object>>("Dog", x =>
            {
                x.IndexerProperty<int>("Id");
                x.IndexerProperty<string>("Name")
					.HasMaxLength(20)
					.IsUnicode();
                x.IndexerProperty<DateTimeOffset>("Created");
            });

			modelBuilder.Entity<PropertyBagDog>()
				.IndexerProperty<string>("Name").HasMaxLength(30);
        }
	}

	public class PropertyBagDog
	{
		public int Id { get; set; }
		public DateTimeOffset Created { get; set; }

		Dictionary<string, object> _properties = new Dictionary<string, object>();
		public object this[string propertyName]
		{
			get => _properties[propertyName];
			set => _properties[propertyName] = value;
		}
	}
}
