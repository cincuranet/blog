﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace EFCore5
{
	public class ElementaryDbContext : DemoDbContext
	{
		public DbSet<Dog> Dogs { get; set; }
		public DbSet<Owner> Owners { get; set; }
	}

	public class Dog
	{
		public int Id { get; set; }
		public string Name { get; set; }
		public DateTimeOffset Created { get; set; }
		public ICollection<Owner> Owners { get; set; }
	}

	public class Owner
	{
		public int Id { get; set; }
		public string FirstName { get; set; }
		public string LastName { get; set; }
		public DateTimeOffset Created { get; set; }
		public ICollection<Dog> Dogs { get; set; }
	}
}
