﻿using Microsoft.EntityFrameworkCore;

namespace EFCore5.EntititesToQueries
{
	public class EntitiesToQueriesContext : DemoDbContext
	{
		protected override void OnModelCreating(ModelBuilder modelBuilder)
		{
			base.OnModelCreating(modelBuilder);
			modelBuilder.Entity<EntityQuery>()
				.ToSqlQuery("select Id, Foo, Bar, Baz from SomeTable union all select Id, Foo, Bar, null from AnotherTable");
		}
	}

	class EntityQuery
	{
		public int Id { get; set; }
		public string Foo { get; set; }
		public decimal Bar { get; set; }
		public double Baz { get; set; }
	}
}
