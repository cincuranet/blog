﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace EFCore5.Migrations
{
	public class BoundedContext : DemoDbContext
	{
		public DbSet<User> Users { get; set; }
	}
	public class BoundedContext2 : DemoDbContext
	{
		public DbSet<User> Users { get; set; }

		protected override void OnModelCreating(ModelBuilder modelBuilder)
		{
			base.OnModelCreating(modelBuilder);

			modelBuilder.Entity<User>().ToTable("Users", x => x.ExcludeFromMigrations());
		}
	}

	public class User
	{
		public int Id { get; set; }
		public string Username { get; set; }
		public byte[] Password { get; set; }
	}
}
