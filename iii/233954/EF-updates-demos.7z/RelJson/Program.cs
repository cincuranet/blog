﻿using Microsoft.EntityFrameworkCore;
using Shared;

using var db = new MyDbContext();
await db.PrepareDatabase();

db.MyEntities.Add(new MyEntity { Name = $"FooBar" });
await db.SaveChangesAsync();

//db.MyEntities.Add(new MyEntity { Name = $"FooBar", Items = [new MyItem { Name = "Baz" }] });
//await db.SaveChangesAsync();

//await db.MyEntities.Where(x => x.Items.Last().Name == "Baz").LoadAsync();

class MyDbContext : DbContextBase
{
    public DbSet<MyEntity> MyEntities { get; set; } = null!;

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);
        modelBuilder.Entity<MyEntity>()
            .OwnsMany(x => x.Items, b => b.ToJson());
    }
}
class MyEntity
{
    public int Id { get; set; }
    public string Name { get; set; } = null!;
    public List<MyItem> Items { get; set; } = [];
}
class MyItem
{
    public int Id { get; set; }
    public string Name { get; set; } = null!;
}