﻿using Microsoft.EntityFrameworkCore;
using Shared;

using var db = new MyDbContext();
await db.PrepareDatabase();
db.Set<MyEntityA>().Add(new MyEntityA { Name = $"FooBar", A = 10 });
db.Set<MyEntityB>().Add(new MyEntityB { Name = $"FooBar", B = 10 });
await db.SaveChangesAsync();

class MyDbContext : DbContextBase
{
    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);
        modelBuilder.Entity<MyEntityBase>(b =>
        {
            b.UseTpcMappingStrategy();
        });
        modelBuilder.Entity<MyEntityA>();
        modelBuilder.Entity<MyEntityB>();
    }
}
abstract class MyEntityBase
{
    public int Id { get; set; }
    public string Name { get; set; } = null!;
}
class MyEntityA : MyEntityBase
{
    public int A { get; set; }
}
class MyEntityB : MyEntityBase
{
    public int B { get; set; }
}
