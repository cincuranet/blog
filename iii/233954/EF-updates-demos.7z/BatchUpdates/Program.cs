﻿using Microsoft.EntityFrameworkCore;
using Shared;

using var db = new MyDbContext();
await db.PrepareDatabase();
await db.MyEntities
    .Where(x => x.Id > 0)
    .ExecuteUpdateAsync(u => u.SetProperty(x => x.Name, x => "Name " + (-x.Id).ToString().ToUpper()));

class MyDbContext : DbContextBase
{
    public DbSet<MyEntity> MyEntities { get; set; } = null!;
}
class MyEntity
{
    public int Id { get; set; }
    public string Name { get; set; } = null!;
}