﻿using Microsoft.EntityFrameworkCore;
using Shared;

using var db = new MyDbContext();
await db.PrepareDatabase();
for (var i = 0; i < 5; i++)
{
    db.MyEntities.Add(new MyEntity { Name = $"Name {i}" });
}
await db.SaveChangesAsync();

class MyDbContext : DbContextBase
{
    public DbSet<MyEntity> MyEntities { get; set; } = null!;

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        base.OnConfiguring(optionsBuilder);
        optionsBuilder.UseSqlServer(o => o.MaxBatchSize(10).MinBatchSize(3));
    }
}
class MyEntity
{
    public int Id { get; set; }
    public string Name { get; set; } = null!;
}