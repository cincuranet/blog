﻿using Microsoft.EntityFrameworkCore;
using Shared;

using var db = new MyDbContext();
await db.PrepareDatabase();
await db.Database.OpenConnectionAsync();
await db.Database.ExecuteSqlRawAsync("set identity_insert MyEntities on");
for (var i = 0; i < 10; i++)
{
    var name = $"Name {i}";
    await db.Database.ExecuteSqlInterpolatedAsync($"insert into MyEntities(Id, Name) values ({i}, {name})");
}
await db.Database.ExecuteSqlRawAsync("set identity_insert MyEntities off");
await db.Database.CloseConnectionAsync();

class MyDbContext : DbContextBase
{
    public DbSet<MyEntity> MyEntities { get; set; } = null!;
}
class MyEntity
{
    public int Id { get; set; }
    public string Name { get; set; } = null!;
}