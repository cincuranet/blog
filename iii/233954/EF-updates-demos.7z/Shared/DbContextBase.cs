﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Diagnostics;

namespace Shared;

public abstract class DbContextBase : DbContext
{
    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        base.OnConfiguring(optionsBuilder);
        optionsBuilder.LogTo(Console.WriteLine, (eventId, _) 
            => eventId == RelationalEventId.CommandExecuting 
                || eventId == RelationalEventId.TransactionStarting
                || eventId == RelationalEventId.TransactionCommitting);
        optionsBuilder.EnableSensitiveDataLogging();
        optionsBuilder.UseSqlServer(@"Data Source=2001:67c:d74:66:5cbb:f6ff:fe9e:eefa;Database=demo;User=sa;Password=Pa$$w0rd;Connect Timeout=10;ConnectRetryCount=0;TrustServerCertificate=true");
    }

    public async Task PrepareDatabase(params string[] commands)
    {
        await Database.EnsureDeletedAsync();
        await Database.EnsureCreatedAsync();
        foreach (var command in commands)
            await Database.ExecuteSqlRawAsync(command);
    }
}
