﻿using Microsoft.EntityFrameworkCore;
using Shared;

using var db = new MyDbContext();
await db.PrepareDatabase("""
    create procedure D_MyEntity(@Id int)
    as
    begin
        delete from MyEntities where Id = @Id;
    end
    """);
db.MyEntities.Add(new MyEntity { Name = $"FooBar" });
await db.SaveChangesAsync();
db.Remove(await db.MyEntities.FirstAsync());
await db.SaveChangesAsync();

class MyDbContext : DbContextBase
{
    public DbSet<MyEntity> MyEntities { get; set; } = null!;

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);
        modelBuilder.Entity<MyEntity>(b =>
        {
            b.DeleteUsingStoredProcedure("D_MyEntity", d => d.HasOriginalValueParameter(x => x.Id));
        });
    }
}
class MyEntity
{
    public int Id { get; set; }
    public string Name { get; set; } = null!;
}