﻿using Microsoft.EntityFrameworkCore;
using Shared;

using var db = new MyDbContext();
await db.PrepareDatabase();

db.MyEntities.Add(new MyEntity { Name = $"FooBar" });
await db.SaveChangesAsync();

//db.MyEntities.Add(new MyEntity { Name = $"FooBar", Items = [new MyItem { Name = "Baz" }] });
//await db.SaveChangesAsync();

class MyDbContext : DbContextBase
{
    public DbSet<MyEntity> MyEntities { get; set; } = null!;
}
class MyEntity
{
    public int Id { get; set; }
    public string Name { get; set; } = null!;
    public List<MyItem> Items { get; set; } = [];
}
class MyItem
{
    public int Id { get; set; }
    public string Name { get; set; } = null!;
}