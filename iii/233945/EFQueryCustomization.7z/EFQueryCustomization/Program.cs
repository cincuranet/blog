﻿namespace EFQueryCustomization;

static class Program
{
    static async Task Main()
    {
        //await CommandInterceptor.Demo();
        //await QueryInterceptor.Demo();
        //await DbFunctionExpression.Demo();
        //await SqlGenerator.Demo();
    }
}
