﻿recreate procedure increment_integer(input int)
returns (original int, new int)
external name 'Example!Example.Procedures.IncrementInteger'
engine FbNetExternalEngine;

recreate procedure increment_bigint(input bigint)
returns (original bigint, new bigint)
external name 'Example!Example.Procedures.IncrementBigint'
engine FbNetExternalEngine;

recreate procedure increment_smallint(input smallint)
returns (original smallint, new smallint)
external name 'Example!Example.Procedures.IncrementSmallint'
engine FbNetExternalEngine;

recreate procedure increment_float(input float)
returns (original float, new float)
external name 'Example!Example.Procedures.IncrementFloat'
engine FbNetExternalEngine;

recreate procedure increment_double(input double precision)
returns (original double precision, new double precision)
external name 'Example!Example.Procedures.IncrementDouble'
engine FbNetExternalEngine;

recreate procedure increment_decimal(input decimal(18,4))
returns (original decimal(18,4), new decimal(18,4))
external name 'Example!Example.Procedures.IncrementDecimal'
engine FbNetExternalEngine;

recreate procedure increment_numeric(input numeric(18,4))
returns (original numeric(18,4), new numeric(18,4))
external name 'Example!Example.Procedures.IncrementNumeric'
engine FbNetExternalEngine;

recreate procedure reverse_varchar(input varchar(20))
returns (original varchar(20), new varchar(20))
external name 'Example!Example.Procedures.ReverseVarchar'
engine FbNetExternalEngine;

recreate procedure reverse_char(input char(20))
returns (original char(20), new char(20))
external name 'Example!Example.Procedures.ReverseChar'
engine FbNetExternalEngine;

recreate procedure add_day_timestamp(input timestamp)
returns (original timestamp, new timestamp)
external name 'Example!Example.Procedures.AddDayTimestamp'
engine FbNetExternalEngine;

recreate procedure add_day_date(input date)
returns (original date, new date)
external name 'Example!Example.Procedures.AddDayDate'
engine FbNetExternalEngine;

recreate procedure add_hour_time(input time)
returns (original time, new time)
external name 'Example!Example.Procedures.AddHourTime'
engine FbNetExternalEngine;

recreate procedure negate_boolean(input boolean)
returns (original boolean, new boolean)
external name 'Example!Example.Procedures.NegateBoolean'
engine FbNetExternalEngine;

recreate procedure current_utc_timestamp
returns (result timestamp)
external name 'Example!Example.Procedures.CurrentUtcTimestamp'
engine FbNetExternalEngine;