﻿using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Text;

class Program
{
    static void Main(string[] args)
    {
        const string FilePath = "weewx.csv";
        var sw = Stopwatch.StartNew();
        //var pointer = Marshal.AllocHGlobal(1024);
        //new Span<byte>(pointer, 1024);
        Span<byte> buffer = stackalloc byte[1024];    
        var data = LoadFile(FilePath, buffer);
        var result = Parse(data.AsMemory());
        Console.WriteLine(sw.Elapsed);
        Console.WriteLine(result.Count);
        //Point[] points = default;
        //ref var foo = ref Foo(points, 10);
    }

    //struct Point
    //{
    //    public int X;
    //    public int Y;
    //}

    //static ref Point Foo(Point[] points, int index)
    //{
    //    return ref points[index];
    //}

    static List<List<ReadOnlyMemory<char>>> Parse(ReadOnlyMemory<char> data)
    {
        var result = new List<List<ReadOnlyMemory<char>>>();
        data = data.Trim();
        foreach (var line in MySplit(data, Environment.NewLine))
        {
            result.Add(MySplit(line, ","));
        }
        return result;
    }

    static List<ReadOnlyMemory<char>> MySplit(ReadOnlyMemory<char> s, ReadOnlySpan<char> separator)
    {
        var result = new List<ReadOnlyMemory<char>>();
        while (true)
        {
            var index = s.Span.IndexOf(separator, StringComparison.Ordinal);
            if (index == -1)
            {
                break;
            }
            result.Add(s.Slice(0, index));
            s = s.Slice(index + separator.Length);
        }
        result.Add(s);
        return result;
    }

    //readonly struct Item
    //{
    //    public readonly string S;
    //    public readonly int Start;
    //    public readonly int End;

    //    public Item(string s, int start, int end)
    //    {
    //        S = s;
    //        Start = start;
    //        End = end;
    //    }

    //    public override string ToString() => S[Start..End];
    //}

    static string LoadFile(string filePath, Span<byte> buffer)
    {
        using (var fs = new FileStream(filePath, FileMode.Open))
        {
            var position = 0;
            while (true)
            {
                var read = fs.Read(buffer);
                if (read == 0)
                    break;
                // process buffer
                position += read;
            }
            return null;
        }
    }
}