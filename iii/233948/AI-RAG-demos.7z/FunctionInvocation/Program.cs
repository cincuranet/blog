﻿using Microsoft.Extensions.AI;

string GetCurrentWeather() => Random.Shared.NextDouble() > 0.5 ? "It's sunny." : "It's raining.";
string LastConference() => "Last conference was 2025-05-08.";
string GetCurrentDateTime() => DateTimeOffset.UtcNow.ToString();

var client = new OllamaChatClient(new Uri("http://192.168.66.34:11434"), "llama3.1")
    .AsBuilder()
    .UseFunctionInvocation()
    .Build();

var options = new ChatOptions()
{
    Tools = [
        AIFunctionFactory.Create(GetCurrentWeather, nameof(GetCurrentWeather)),
        AIFunctionFactory.Create(LastConference, nameof(LastConference)),
        AIFunctionFactory.Create(GetCurrentDateTime, nameof(GetCurrentDateTime))],
};

await DoQuestion("Is it going to rain?");
await DoQuestion("How many days ago was the last conference?");
await DoQuestion("Who is Barack Obama?");

async Task DoQuestion(string question)
{
    Console.WriteLine($"> {question}");
    await foreach (var update in client.GetStreamingResponseAsync(question, options))
    {
        Console.Write(update);
    }
    Console.WriteLine();
}