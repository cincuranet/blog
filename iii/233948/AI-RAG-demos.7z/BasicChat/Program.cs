﻿using Microsoft.Extensions.AI;

var chatClient = new OllamaChatClient("http://192.168.66.34:11434", "deepseek-r1");
List<ChatMessage> history = [];
while (true)
{
    Console.Write("?: ");
    history.Add(new(ChatRole.User, Console.ReadLine()));

    List<ChatResponseUpdate> updates = [];
    await foreach (var update in chatClient.GetStreamingResponseAsync(history))
    {
        Console.Write(update);
        updates.Add(update);
    }
    Console.WriteLine();

    history.AddMessages(updates);
}