﻿Demo.Do();

class Demo
{
    static ThreadLocal<string> localData = new();

    //[ThreadStatic]
    //static string localData;

    public static void Do()
    {
        localData.Value = "Initial Value";

        var thread1 = new Thread(() =>
        {
            localData.Value = "Thread 1 Data";
            Console.WriteLine($"Thread 1: {localData.Value}");
        });

        var thread2 = new Thread(() =>
        {
            localData.Value = "Thread 2 Data";
            Console.WriteLine($"Thread 2: {localData.Value}");
        });

        thread1.Start();
        thread2.Start();

        thread1.Join();
        thread2.Join();

        Console.WriteLine($"Main Thread: {localData.Value}");
    }
}