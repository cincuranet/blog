﻿await using (var demo = GetDemo())
{
    demo.Do();
}
Console.WriteLine("Done");

Demo GetDemo()
{
    return new Demo();
}

class Demo : IAsyncDisposable
{
    public void Do()
    {
        Console.WriteLine("Doing...");
    }

    public async ValueTask DisposeAsync()
    {
        await Task.Delay(1000);
    }
}
