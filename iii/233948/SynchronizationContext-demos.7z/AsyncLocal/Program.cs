﻿await Demo.Do();

class Demo
{
    static AsyncLocal<string> localData = new();

    public static async Task Do()
    {
        localData.Value = "Initial Value";

        var task1 = Task.Run(() =>
        {
            localData.Value = "Task 1 Data";
            Console.WriteLine($"Task 1: {localData.Value}");
        });

        var task2 = Task.Run(() =>
        {
            localData.Value = "Task 2 Data";
            Console.WriteLine($"Task 2: {localData.Value}");
        });

        await Task.WhenAll(task1, task2);

        Console.WriteLine($"Main: {localData.Value}");
    }
}