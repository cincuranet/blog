namespace WinFormsAwait
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

/*
    Task captures SC (EC flows automatically)
    ConfigureAwait(false)
    performance
    deadlocks
*/

        private async void button1_Click(object sender, EventArgs e)
        {
            button1.Text = "Running...";
            await Delay(5);
            button1.Text = "Done";
        }

        private async Task Delay(int seconds)
        {
            for (var i = 0; i < seconds; i++)
            {
                await Task.Delay(1000);
            }
        }
    }
}
