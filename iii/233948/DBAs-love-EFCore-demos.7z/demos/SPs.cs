using Microsoft.EntityFrameworkCore;

namespace demos;

class SPs
{
    public static async Task Demo()
    {
        using var db = new MyContext();

        await db.PrepareDatabase(
            """
            create procedure D_FooBar(@Id int)
            as
            begin
                delete from FooBars where Id = @Id;
            end
            """);

        var entry = db.Attach(new MyDbContextBase.FooBar { Id = 1 });
        entry.State = EntityState.Deleted;
        await db.SaveChangesAsync();
    }

    class MyContext : MyDbContextBase
    {
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<FooBar>(b =>
            {
                b.DeleteUsingStoredProcedure("D_FooBar", d => d.HasOriginalValueParameter("Id"));
            });
        }
    }
}
