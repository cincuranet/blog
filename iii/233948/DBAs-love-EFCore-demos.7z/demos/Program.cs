﻿using demos;

static class Program
{
    static async Task Main()
    {
        //await BulkUpdates.Demo();
        //await FromSql.Demo();
        //await FunctionMapping.Demo();
        //await SPs.Demo();
        //await Views.Demo();
        //await JSONColumns.Demo();
        //await PrimitiveCollections.Demo();
        //await ValueConversions.Demo();
    }
}