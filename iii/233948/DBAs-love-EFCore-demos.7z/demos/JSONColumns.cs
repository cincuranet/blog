using Microsoft.EntityFrameworkCore;

namespace demos;

class JSONColumns
{
    public static async Task Demo()
    {
        using var db = new MyContext();

        await db.PrepareDatabase();

        await db.AddAsync(new JSONColumnEntity() { Duration = new Duration(1, 30) });
        await db.SaveChangesAsync();
        await db.Set<JSONColumnEntity>().Select(x => x.Duration.Hours).LoadAsync();
    }

    class MyContext : MyDbContextBase
    {
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<JSONColumnEntity>(b =>
            {
                b.OwnsOne(x => x.Duration).ToJson();
            });
        }
    }

    class JSONColumnEntity
    {
        public int Id { get; set; }
        public Duration Duration { get; set; }
    }

    class Duration(int hours, int minutes)
    {
        public int Hours { get; set; } = hours;
        public int Minutes { get; set; } = minutes;
    }
}
