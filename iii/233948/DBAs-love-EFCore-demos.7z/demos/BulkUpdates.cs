using System.Data;
using Microsoft.EntityFrameworkCore;

namespace demos;

class BulkUpdates
{
    public static async Task Demo()
    {
        using var db = new MyContext();

        await db.PrepareDatabase();

        await db.FooBars
            .Where(x => x.Id < 0)
            .ExecuteUpdateAsync(s => s.SetProperty(x => x.Float, x => -x.Id));
    }

    class MyContext : MyDbContextBase
    {
    }
}
