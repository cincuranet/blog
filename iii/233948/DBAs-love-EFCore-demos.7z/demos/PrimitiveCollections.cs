using Microsoft.EntityFrameworkCore;

namespace demos;

class PrimitiveCollections
{
    public static async Task Demo()
    {
        using var db = new MyContext();

        await db.PrepareDatabase();

        await db.AddAsync(new PrimitiveCollectionEntity() { Dates = [DateOnly.MinValue, DateOnly.MaxValue, new DateOnly(1999, 12, 31)] });
        await db.SaveChangesAsync();
        await db.Set<PrimitiveCollectionEntity>().Where(x => x.Dates.Skip(1).Count() > 1).Select(x => x.Dates.Last().Day).LoadAsync();
    }

    class MyContext : MyDbContextBase
    {
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            modelBuilder.Entity<PrimitiveCollectionEntity>();
        }
    }

    class PrimitiveCollectionEntity
    {
        public int Id { get; set; }
        public DateOnly[] Dates { get; set; }
    }
}
