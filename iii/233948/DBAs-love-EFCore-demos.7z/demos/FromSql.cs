using System.Data;
using Microsoft.EntityFrameworkCore;

namespace demos;

class FromSql
{
    public static async Task Demo()
    {
        using var db = new MyContext();

        await db.PrepareDatabase();

        var id = 99;
        await db.FooBars.FromSqlInterpolated($"select * from FooBars where Name is not null and Id > {id}")
            .OrderBy(x => x.Name)
            .LoadAsync();

        await db.Database.SqlQueryRaw<Data>("select Id, Name from FooBars")
            .Take(5)
            .LoadAsync();

        await db.Database.ExecuteSqlRawAsync("update FooBars set Name = 'Updated' where Id = 1");
    }

    class MyContext : MyDbContextBase
    {
    }

    record Data(int Id, string Name);
}
