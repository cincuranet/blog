﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Diagnostics;

namespace demos;

abstract class MyDbContextBase : DbContext
{
    public DbSet<FooBar> FooBars { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        base.OnConfiguring(optionsBuilder);
        optionsBuilder.LogTo(Console.WriteLine, (eventId, _) => eventId == RelationalEventId.CommandExecuting);
        optionsBuilder.EnableSensitiveDataLogging();
        optionsBuilder.UseSqlServer(@"Data Source=2001:67c:d74:66:5cbb:f6ff:fe9e:eefa;Database=demo;User=sa;Password=Pa$$w0rd;Connect Timeout=10;ConnectRetryCount=0;TrustServerCertificate=true");
    }

    public async Task PrepareDatabase(params string[] commands)
    {
        await Database.EnsureDeletedAsync();
        await Database.EnsureCreatedAsync();
        foreach (var command in commands)
            await Database.ExecuteSqlRawAsync(command);
    }

    public class FooBar
    {
        public int Id { get; set; }
        public string? Name { get; set; }
        public float Float { get; set; }
    }
}
