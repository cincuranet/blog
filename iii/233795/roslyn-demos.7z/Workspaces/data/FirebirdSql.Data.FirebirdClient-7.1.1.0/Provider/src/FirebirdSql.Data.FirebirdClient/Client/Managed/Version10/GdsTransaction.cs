﻿/*
 *    The contents of this file are subject to the Initial
 *    Developer's Public License Version 1.0 (the "License");
 *    you may not use this file except in compliance with the
 *    License. You may obtain a copy of the License at
 *    https://github.com/FirebirdSQL/NETProvider/blob/master/license.txt.
 *
 *    Software distributed under the License is distributed on
 *    an "AS IS" basis, WITHOUT WARRANTY OF ANY KIND, either
 *    express or implied. See the License for the specific
 *    language governing rights and limitations under the License.
 *
 *    All Rights Reserved.
 */

//$Authors = Carlos Guzman Alvarez, Jiri Cincura (jiri@cincura.net)

using System;
using System.Data;
using System.IO;

using FirebirdSql.Data.Common;

namespace FirebirdSql.Data.Client.Managed.Version10
{
	internal class GdsTransaction : TransactionBase
	{
		#region Events

		public override event EventHandler Update;

		#endregion

		#region Fields

		private int _handle;
		private bool _disposed;
		private GdsDatabase _database;
		private TransactionState _state;

		#endregion

		#region Properties

		public override int Handle
		{
			get { return _handle; }
		}

		public override TransactionState State
		{
			get { return _state; }
		}

		#endregion

		#region Constructors

		public GdsTransaction(IDatabase db)
		{
			if (!(db is GdsDatabase))
			{
				throw new ArgumentException($"Specified argument is not of {nameof(GdsDatabase)} type.");
			}

			_database = (GdsDatabase)db;
			_state = TransactionState.NoTransaction;
		}

		#endregion

		#region IDisposable methods

		public override void Dispose()
		{
			if (!_disposed)
			{
				_disposed = true;
				if (_state != TransactionState.NoTransaction)
				{
					Rollback();
				}
				_database = null;
				_handle = 0;
				_state = TransactionState.NoTransaction;
				base.Dispose();
			}
		}

		#endregion

		#region Methods

		public override void BeginTransaction(TransactionParameterBuffer tpb)
		{
			if (_state != TransactionState.NoTransaction)
			{
				throw new InvalidOperationException();
			}

			try
			{
				_database.Xdr.Write(IscCodes.op_transaction);
				_database.Xdr.Write(_database.Handle);
				_database.Xdr.WriteBuffer(tpb.ToArray());
				_database.Xdr.Flush();

				var response = _database.ReadResponse<GenericResponse>();

				_database.TransactionCount++;

				_handle = response.ObjectHandle;
				_state = TransactionState.Active;
			}
			catch (IOException ex)
			{
				throw IscException.ForErrorCode(IscCodes.isc_network_error, ex);
			}
		}

		public override void Commit()
		{
			EnsureActiveTransactionState();

			try
			{
				_database.Xdr.Write(IscCodes.op_commit);
				_database.Xdr.Write(_handle);
				_database.Xdr.Flush();

				_database.ReadResponse();

				_database.TransactionCount--;

				Update?.Invoke(this, new EventArgs());

				_state = TransactionState.NoTransaction;
			}
			catch (IOException ex)
			{
				throw IscException.ForErrorCode(IscCodes.isc_network_error, ex);
			}
		}

		public override void Rollback()
		{
			EnsureActiveTransactionState();

			try
			{
				_database.Xdr.Write(IscCodes.op_rollback);
				_database.Xdr.Write(_handle);
				_database.Xdr.Flush();

				_database.ReadResponse();

				_database.TransactionCount--;

				Update?.Invoke(this, new EventArgs());

				_state = TransactionState.NoTransaction;
			}
			catch (IOException ex)
			{
				throw IscException.ForErrorCode(IscCodes.isc_network_error, ex);
			}
		}

		public override void CommitRetaining()
		{
			EnsureActiveTransactionState();

			try
			{
				_database.Xdr.Write(IscCodes.op_commit_retaining);
				_database.Xdr.Write(_handle);
				_database.Xdr.Flush();

				_database.ReadResponse();

				_state = TransactionState.Active;
			}
			catch (IOException ex)
			{
				throw IscException.ForErrorCode(IscCodes.isc_network_error, ex);
			}
		}

		public override void RollbackRetaining()
		{
			EnsureActiveTransactionState();

			try
			{
				_database.Xdr.Write(IscCodes.op_rollback_retaining);
				_database.Xdr.Write(_handle);
				_database.Xdr.Flush();

				_database.ReadResponse();

				_state = TransactionState.Active;
			}
			catch (IOException ex)
			{
				throw IscException.ForErrorCode(IscCodes.isc_network_error, ex);
			}
		}

		#endregion

		#region Two Phase Commit Methods

		public override void Prepare()
		{
			EnsureActiveTransactionState();

			try
			{
				_state = TransactionState.NoTransaction;

				_database.Xdr.Write(IscCodes.op_prepare);
				_database.Xdr.Write(_handle);
				_database.Xdr.Flush();

				_database.ReadResponse();

				_state = TransactionState.Prepared;
			}
			catch (IOException ex)
			{
				throw IscException.ForErrorCode(IscCodes.isc_network_error, ex);
			}
		}

		public override void Prepare(byte[] buffer)
		{
			EnsureActiveTransactionState();

			try
			{
				_state = TransactionState.NoTransaction;

				_database.Xdr.Write(IscCodes.op_prepare2);
				_database.Xdr.Write(_handle);
				_database.Xdr.WriteBuffer(buffer, buffer.Length);
				_database.Xdr.Flush();

				_database.ReadResponse();

				_state = TransactionState.Prepared;
			}
			catch (IOException ex)
			{
				throw IscException.ForErrorCode(IscCodes.isc_network_error, ex);
			}
		}

		#endregion
	}
}
