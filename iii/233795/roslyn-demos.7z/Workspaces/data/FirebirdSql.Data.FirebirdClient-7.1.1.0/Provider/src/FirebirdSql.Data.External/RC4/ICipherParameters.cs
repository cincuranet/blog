using System;

namespace Org.BouncyCastle.Crypto
{
    /**
     * all parameter classes implement this.
     */
    internal interface ICipherParameters
    {
    }
}
