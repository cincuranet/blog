﻿using System.Threading;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace Requests.Controllers
{
	public class HomeController : Controller
	{
		const int Delay = 2000;

		[HttpGet("/hello")]
		public string Hello()
		{
			Thread.Sleep(Delay);
			return "Hello World";
		}

		[HttpGet("/hello-sync-over-async")]
		public string HelloSyncOverAsync()
		{
			Task.Delay(Delay).Wait();
			return "Hello World";
		}

		[HttpGet("/hello-async-over-sync")]
		public async Task<string> HelloAsyncOverSync()
		{
			await Task.Run(() => Thread.Sleep(Delay));
			return "Hello World";
		}

		[HttpGet("/hello-async")]
		public async Task<string> HelloAsync()
		{
			await Task.Delay(Delay);
			return "Hello World";
		}
	}
}
