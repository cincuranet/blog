﻿namespace TestApp.Resources
{
	public static partial class ResourcesServiceCollectionInstaller
	{ }
}
