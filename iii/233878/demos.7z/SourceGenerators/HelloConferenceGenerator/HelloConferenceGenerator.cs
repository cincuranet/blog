﻿using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.Text;
using System.Collections.Generic;
using System.Text;

namespace HelloConferenceGenerator
{
	[Generator]
	public class HelloConferenceGenerator : ISourceGenerator
	{
		public void Execute(GeneratorExecutionContext context)
		{
			var sourceBuilder = new StringBuilder(@"
using System;

namespace HelloConferenceGenerated
{
    public static class HelloConference
    {
        public static void SayHello() 
        {
            Console.WriteLine(""Hello conference DDC!"");
            Console.WriteLine(""The following syntax trees existed in the compilation that created this program:"");
");
			foreach(var item in GetSyntaxTreeOutputs(context))
			{
				sourceBuilder.AppendLine(item);
			}
			sourceBuilder.Append(@"
        }
    }
}");
			context.AddSource("HelloConferenceGenerated", SourceText.From(sourceBuilder.ToString(), Encoding.UTF8));
		}

		static IEnumerable<string> GetSyntaxTreeOutputs(GeneratorExecutionContext context)
		{
			var syntaxTrees = context.Compilation.SyntaxTrees;
			foreach (var tree in syntaxTrees)
			{
				yield return $@"Console.WriteLine(@"" - {tree.FilePath}"");";
			}
		}

		public void Initialize(GeneratorInitializationContext context)
		{ }
	}
}
