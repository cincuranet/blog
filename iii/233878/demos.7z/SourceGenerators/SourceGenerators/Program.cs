﻿using System;
using AutoNotify;

namespace SourceGenerators
{
	class Program
	{
		static void Main(string[] args)
		{
			//HelloConferenceGenerated.HelloConference.SayHello();
			//new CSV.Participants.Item();
			//new Notify().Car;
		}
	}

	partial class Notify
	{
		[AutoNotify]
		public string _car;
	}
}
