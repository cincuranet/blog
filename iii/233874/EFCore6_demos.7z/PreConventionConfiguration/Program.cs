﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Diagnostics;

using var db = new MyContext();
db.Database.EnsureDeleted();
db.Database.EnsureCreated();

public class MyContext : DbContext
{
	protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
	{
		base.OnConfiguring(optionsBuilder);
		if (optionsBuilder.IsConfigured)
			return;
		optionsBuilder.UseSqlServer(@"Server=.;Database=netdd;Trusted_Connection=true;ConnectRetryCount=0");
		optionsBuilder.LogTo(Console.WriteLine, new[] { RelationalEventId.CommandExecuting });
		optionsBuilder.EnableSensitiveDataLogging();
	}

	protected override void OnModelCreating(ModelBuilder modelBuilder)
	{
		base.OnModelCreating(modelBuilder);

		modelBuilder.Entity<SomeData>();
		modelBuilder.Entity<OtherData>();

		//foreach (var entity in modelBuilder.Model.GetEntityTypes())
		//{
		//	foreach (var property in entity.GetProperties())
		//	{
		//		if (property.ClrType != typeof(string))
		//			continue;
		//		property.SetMaxLength(200);
		//	}
		//}
	}

	protected override void ConfigureConventions(ModelConfigurationBuilder configurationBuilder)
	{
		base.ConfigureConventions(configurationBuilder);
		
		configurationBuilder
			.Properties<string>()
			.HaveMaxLength(200);
		configurationBuilder
			.Properties<DateTime>()
			.HaveConversion<long>();
	}
}

public record SomeData(int Id, string Foo, double Bar);
public record OtherData(int Id, string Name);
