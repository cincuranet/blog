namespace ControlSynchronization
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            button1.Text = "Running...";
            ThreadPool.QueueUserWorkItem(_ =>
            {
                Thread.Sleep(5000);
                button1.Invoke(() =>
                {
                    button1.Text = "Done";
                });
            });
        }
    }
}
