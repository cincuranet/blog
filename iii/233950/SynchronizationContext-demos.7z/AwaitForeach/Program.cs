﻿await foreach (var number in GetNumbers(5))
{
    Console.WriteLine(number);
}

async IAsyncEnumerable<int> GetNumbers(int max)
{
    for (var i = 0; i < max; i++)
    {
        await Task.Delay(1000);
        yield return i;
    }
}
