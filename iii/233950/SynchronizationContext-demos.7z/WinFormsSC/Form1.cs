namespace WinFormsSC
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            button1.Text = "Running...";
            var sc = SynchronizationContext.Current!;
            ThreadPool.QueueUserWorkItem(_ =>
            {
                Thread.Sleep(5000);
                sc.Post(_ =>
                {
                    button1.Text = "Done";
                }, null);
            });
        }
    }
}
