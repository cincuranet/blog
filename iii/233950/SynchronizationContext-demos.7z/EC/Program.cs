﻿Demo.Do();

/* 
    HostExecutionContext, SecurityContext, ...
*/ 

class Demo
{
    static AsyncLocal<string> localData = new();

    public static void Do()
    {
        localData.Value = "Initial Value";

        using (var ec1 = ExecutionContext.Capture())
        {
            ExecutionContext.Run(ec1!, _ =>
            {
                localData.Value = "Task 1 Data";
                Console.WriteLine($"Task 1: {localData.Value}");
            }, null);
        }

        var ec2 = ExecutionContext.Capture();
        ExecutionContext.Run(ec2!, _ =>
        {
            localData.Value = "Task 2 Data";
            Console.WriteLine($"Task 2: {localData.Value}");
        }, null);

        Console.WriteLine($"Main: {localData.Value}");
    }
}